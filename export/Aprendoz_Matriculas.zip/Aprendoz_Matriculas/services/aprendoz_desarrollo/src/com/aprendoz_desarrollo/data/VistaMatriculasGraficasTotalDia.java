
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaMatriculasGraficasTotalDia
 *  05/06/2013 15:48:45
 * 
 */
public class VistaMatriculasGraficasTotalDia {

    private VistaMatriculasGraficasTotalDiaId id;

    public VistaMatriculasGraficasTotalDia() {
    }

    public VistaMatriculasGraficasTotalDia(VistaMatriculasGraficasTotalDiaId id) {
        this.id = id;
    }

    public VistaMatriculasGraficasTotalDiaId getId() {
        return id;
    }

    public void setId(VistaMatriculasGraficasTotalDiaId id) {
        this.id = id;
    }

}
