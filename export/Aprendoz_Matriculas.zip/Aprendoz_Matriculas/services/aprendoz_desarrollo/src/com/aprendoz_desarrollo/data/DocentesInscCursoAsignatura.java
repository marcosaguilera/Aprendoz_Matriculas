
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesInscCursoAsignatura
 *  05/06/2013 15:48:45
 * 
 */
public class DocentesInscCursoAsignatura {

    private DocentesInscCursoAsignaturaId id;

    public DocentesInscCursoAsignatura() {
    }

    public DocentesInscCursoAsignatura(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

    public DocentesInscCursoAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

}
