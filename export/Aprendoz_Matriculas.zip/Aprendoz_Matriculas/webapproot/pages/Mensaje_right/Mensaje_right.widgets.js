Mensaje_right.widgets = {
	layoutBox1: ["wm.Layout", {"_classes":{"domNode":["wm_BackgroundColor_VeryLightGray"]},"height":"100%","width":"100%","horizontalAlign":"left","verticalAlign":"top"}, {}, {
		panel1: ["wm.Panel", {"height":"48px","width":"499px","layoutKind":"left-to-right","horizontalAlign":"center","verticalAlign":"top"}, {}, {
			picture1: ["wm.Picture", {"height":"100%","width":"100px","border":"0","source":"resources/images/buttons/ok.png","aspect":"h"}, {}]
		}],
		label1: ["wm.Label", {"_classes":{"domNode":["wm_FontSizePx_12px","wm_TextDecoration_Bold"]},"height":"59px","width":"499px","border":"0","caption":"CORRECTO: </br> El estudiante ha sido Matrículado exitosamente. Haga Click el 'Close' para cerrar la ventana de dialogo.","singleLine":false}, {}, {
			format: ["wm.DataFormatter", {}, {}]
		}]
	}]
}