
package com.aprendoz_desarrollo;



/**
 *  Query names for service "aprendoz_desarrollo"
 *  05/06/2013 15:51:10
 * 
 */
public class Aprendoz_desarrolloConstants {

    public final static String getUserDataQueryName = "getUserData";
    public final static String showInformationUserQueryName = "showInformationUser";
    public final static String getFormulario5aByIdQueryName = "getFormulario5aById";

    private Aprendoz_desarrolloConstants() {
        throw new UnsupportedOperationException();
    }

}
