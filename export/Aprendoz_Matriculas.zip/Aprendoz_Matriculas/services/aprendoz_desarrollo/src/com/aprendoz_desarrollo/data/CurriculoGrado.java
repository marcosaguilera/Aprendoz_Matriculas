
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CurriculoGrado
 *  05/06/2013 15:48:46
 * 
 */
public class CurriculoGrado {

    private CurriculoGradoId id;

    public CurriculoGrado() {
    }

    public CurriculoGrado(CurriculoGradoId id) {
        this.id = id;
    }

    public CurriculoGradoId getId() {
        return id;
    }

    public void setId(CurriculoGradoId id) {
        this.id = id;
    }

}
