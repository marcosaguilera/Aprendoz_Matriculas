
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CalifEst
 *  05/06/2013 15:48:46
 * 
 */
public class CalifEst {

    private CalifEstId id;

    public CalifEst() {
    }

    public CalifEst(CalifEstId id) {
        this.id = id;
    }

    public CalifEstId getId() {
        return id;
    }

    public void setId(CalifEstId id) {
        this.id = id;
    }

}
