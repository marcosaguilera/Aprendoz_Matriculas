dojo.declare("Mensaje_ok", wm.Page, {
	start: function() {
		
	},
	_end: 0
});