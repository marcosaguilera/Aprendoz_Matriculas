dojo.declare("Mensaje_right", wm.Page, {
	start: function() {
		
	},
	_end: 0
});