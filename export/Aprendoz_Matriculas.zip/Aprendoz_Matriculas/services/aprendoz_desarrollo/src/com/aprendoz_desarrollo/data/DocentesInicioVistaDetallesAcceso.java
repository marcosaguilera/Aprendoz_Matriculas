
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesInicioVistaDetallesAcceso
 *  05/06/2013 15:48:46
 * 
 */
public class DocentesInicioVistaDetallesAcceso {

    private DocentesInicioVistaDetallesAccesoId id;

    public DocentesInicioVistaDetallesAcceso() {
    }

    public DocentesInicioVistaDetallesAcceso(DocentesInicioVistaDetallesAccesoId id) {
        this.id = id;
    }

    public DocentesInicioVistaDetallesAccesoId getId() {
        return id;
    }

    public void setId(DocentesInicioVistaDetallesAccesoId id) {
        this.id = id;
    }

}
