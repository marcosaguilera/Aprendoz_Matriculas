
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AprEsperados
 *  05/06/2013 15:48:45
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperados() {
    }

    public AprEsperados(AprEsperadosId id) {
        this.id = id;
    }

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}
