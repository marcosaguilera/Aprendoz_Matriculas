
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AprLogrados
 *  05/06/2013 15:48:46
 * 
 */
public class AprLogrados {

    private AprLogradosId id;

    public AprLogrados() {
    }

    public AprLogrados(AprLogradosId id) {
        this.id = id;
    }

    public AprLogradosId getId() {
        return id;
    }

    public void setId(AprLogradosId id) {
        this.id = id;
    }

}
