dojo.declare("Mensaje_error", wm.Page, {
	start: function() {
		
	},
	_end: 0
});