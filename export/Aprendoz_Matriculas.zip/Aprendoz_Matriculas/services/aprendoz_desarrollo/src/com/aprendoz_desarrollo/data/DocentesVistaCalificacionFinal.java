
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaCalificacionFinal
 *  05/06/2013 15:48:46
 * 
 */
public class DocentesVistaCalificacionFinal {

    private DocentesVistaCalificacionFinalId id;

    public DocentesVistaCalificacionFinal() {
    }

    public DocentesVistaCalificacionFinal(DocentesVistaCalificacionFinalId id) {
        this.id = id;
    }

    public DocentesVistaCalificacionFinalId getId() {
        return id;
    }

    public void setId(DocentesVistaCalificacionFinalId id) {
        this.id = id;
    }

}
