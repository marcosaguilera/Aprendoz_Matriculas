
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VProfesorAsignatura
 *  05/06/2013 15:48:46
 * 
 */
public class VProfesorAsignatura {

    private VProfesorAsignaturaId id;

    public VProfesorAsignatura() {
    }

    public VProfesorAsignatura(VProfesorAsignaturaId id) {
        this.id = id;
    }

    public VProfesorAsignaturaId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaId id) {
        this.id = id;
    }

}
