
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.AdministracionVistaPersonas
 *  05/06/2013 15:48:46
 * 
 */
public class AdministracionVistaPersonas {

    private AdministracionVistaPersonasId id;

    public AdministracionVistaPersonas() {
    }

    public AdministracionVistaPersonas(AdministracionVistaPersonasId id) {
        this.id = id;
    }

    public AdministracionVistaPersonasId getId() {
        return id;
    }

    public void setId(AdministracionVistaPersonasId id) {
        this.id = id;
    }

}
