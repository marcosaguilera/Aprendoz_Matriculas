
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.TmpBoletin20122013
 *  05/06/2013 15:48:46
 * 
 */
public class TmpBoletin20122013 {

    private TmpBoletin20122013Id id;

    public TmpBoletin20122013() {
    }

    public TmpBoletin20122013(TmpBoletin20122013Id id) {
        this.id = id;
    }

    public TmpBoletin20122013Id getId() {
        return id;
    }

    public void setId(TmpBoletin20122013Id id) {
        this.id = id;
    }

}
