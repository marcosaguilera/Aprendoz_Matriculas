
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.CalifEstCopy
 *  05/06/2013 15:48:46
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopy() {
    }

    public CalifEstCopy(CalifEstCopyId id) {
        this.id = id;
    }

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}
