Login.widgets = {
	layoutBox: ["wm.Layout", {"height":"100%"}, {}, {
		spacer1: ["wm.Spacer", {"height":"64px","width":"96px"}, {}],
		panel1: ["wm.Panel", {"height":"144px","width":"100%","layoutKind":"left-to-right","verticalAlign":"bottom","horizontalAlign":"center"}, {}, {
			logo: ["wm.Picture", {"height":"103px","width":"352px","border":"0","source":"resources/images/logos/logoAprendoz.jpg","aspect":"h"}, {}]
		}],
		loginMainPanel: ["wm.Panel", {"height":"280px","padding":"10","layoutKind":"left-to-right"}, {}, {
			spacer5: ["wm.Spacer", {"width":"100%"}, {}],
			loginInputPanel: ["wm.Panel", {"_classes":{"domNode":["wm_Border_StyleFirefoxCurved4px","wm_Border_StyleSolid","wm_Border_Size1px","wm_Border_ColorLightGray","wm_Border_TopStyleCurved4px","wm_Border_BottomStyleCurved4px","wm_FontSizePx_12px","wm_SilverBlueTheme_LightBlueInsetPanel"]},"width":"320px","border":"3","padding":"5","borderColor":"#CD0000"}, {}, {
				usernameInput: ["wm.Editor", {"caption":"Usuario","height":"28px","captionSize":"80px"}, {}, {
					editor: ["wm._TextEditor", {}, {}]
				}],
				passwordInput: ["wm.Editor", {"caption":"Contraseña","height":"28px","captionSize":"80px"}, {}, {
					editor: ["wm._TextEditor", {"password":true}, {}]
				}],
				loginButtonPanel: ["wm.Panel", {"height":"40px","padding":"4","layoutKind":"left-to-right","horizontalAlign":"right"}, {}, {
					loginButton: ["wm.Button", {"width":"100px","caption":"Acceder","margin":"0","borderColor":"#CD0000"}, {"onclick":"loginButtonClick"}]
				}],
				spacer3: ["wm.Spacer", {"height":"30px"}, {}],
				loginErrorMsg: ["wm.Label", {"height":"100%","border":"0","caption":" "}, {}, {
					format: ["wm.DataFormatter", {}, {}]
				}]
			}],
			spacer4: ["wm.Spacer", {"width":"100%"}, {}]
		}]
	}]
}