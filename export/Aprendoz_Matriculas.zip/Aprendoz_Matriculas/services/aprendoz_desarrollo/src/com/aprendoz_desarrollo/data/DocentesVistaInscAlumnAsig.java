
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesVistaInscAlumnAsig
 *  05/06/2013 15:48:46
 * 
 */
public class DocentesVistaInscAlumnAsig {

    private DocentesVistaInscAlumnAsigId id;

    public DocentesVistaInscAlumnAsig() {
    }

    public DocentesVistaInscAlumnAsig(DocentesVistaInscAlumnAsigId id) {
        this.id = id;
    }

    public DocentesVistaInscAlumnAsigId getId() {
        return id;
    }

    public void setId(DocentesVistaInscAlumnAsigId id) {
        this.id = id;
    }

}
