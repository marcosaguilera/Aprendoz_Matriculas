
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaPadresTransportePersonas
 *  05/06/2013 15:48:46
 * 
 */
public class VistaPadresTransportePersonas {

    private VistaPadresTransportePersonasId id;

    public VistaPadresTransportePersonas() {
    }

    public VistaPadresTransportePersonas(VistaPadresTransportePersonasId id) {
        this.id = id;
    }

    public VistaPadresTransportePersonasId getId() {
        return id;
    }

    public void setId(VistaPadresTransportePersonasId id) {
        this.id = id;
    }

}
