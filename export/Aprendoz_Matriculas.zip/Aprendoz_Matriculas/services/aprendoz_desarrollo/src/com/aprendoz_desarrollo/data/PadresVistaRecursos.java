
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaRecursos
 *  05/06/2013 15:48:45
 * 
 */
public class PadresVistaRecursos {

    private PadresVistaRecursosId id;

    public PadresVistaRecursos() {
    }

    public PadresVistaRecursos(PadresVistaRecursosId id) {
        this.id = id;
    }

    public PadresVistaRecursosId getId() {
        return id;
    }

    public void setId(PadresVistaRecursosId id) {
        this.id = id;
    }

}
