
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.PadresVistaAprendizajes
 *  05/06/2013 15:48:46
 * 
 */
public class PadresVistaAprendizajes {

    private PadresVistaAprendizajesId id;

    public PadresVistaAprendizajes() {
    }

    public PadresVistaAprendizajes(PadresVistaAprendizajesId id) {
        this.id = id;
    }

    public PadresVistaAprendizajesId getId() {
        return id;
    }

    public void setId(PadresVistaAprendizajesId id) {
        this.id = id;
    }

}
