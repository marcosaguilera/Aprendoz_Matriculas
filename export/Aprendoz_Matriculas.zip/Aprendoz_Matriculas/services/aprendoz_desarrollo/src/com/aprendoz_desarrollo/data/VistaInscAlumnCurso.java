
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaInscAlumnCurso
 *  05/06/2013 15:48:46
 * 
 */
public class VistaInscAlumnCurso {

    private VistaInscAlumnCursoId id;

    public VistaInscAlumnCurso() {
    }

    public VistaInscAlumnCurso(VistaInscAlumnCursoId id) {
        this.id = id;
    }

    public VistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(VistaInscAlumnCursoId id) {
        this.id = id;
    }

}
