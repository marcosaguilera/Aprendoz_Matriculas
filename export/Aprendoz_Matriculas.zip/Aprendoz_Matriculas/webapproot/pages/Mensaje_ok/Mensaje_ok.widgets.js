Mensaje_ok.widgets = {
	layoutBox1: ["wm.Layout", {"_classes":{"domNode":["wm_BackgroundColor_VeryLightGray"]},"height":"100%","width":"100%","horizontalAlign":"left","verticalAlign":"top"}, {}, {
		spacer1: ["wm.Spacer", {"height":"12px","width":"95px"}, {}],
		loader: ["wm.Picture", {"height":"24px","width":"270px","border":"0","source":"resources/images/buttons/loader.gif"}, {}],
		label1: ["wm.Label", {"height":"24px","width":"270px","border":"0","caption":"Espere, estamos cargando información necesaria","align":"center"}, {}, {
			format: ["wm.DataFormatter", {}, {}]
		}]
	}]
}