
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VProfesorAsignaturaCompleto
 *  05/06/2013 15:48:46
 * 
 */
public class VProfesorAsignaturaCompleto {

    private VProfesorAsignaturaCompletoId id;

    public VProfesorAsignaturaCompleto() {
    }

    public VProfesorAsignaturaCompleto(VProfesorAsignaturaCompletoId id) {
        this.id = id;
    }

    public VProfesorAsignaturaCompletoId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaCompletoId id) {
        this.id = id;
    }

}
