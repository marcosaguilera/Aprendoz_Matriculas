
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.VistaEnvioCorreo
 *  05/06/2013 15:48:46
 * 
 */
public class VistaEnvioCorreo {

    private VistaEnvioCorreoId id;

    public VistaEnvioCorreo() {
    }

    public VistaEnvioCorreo(VistaEnvioCorreoId id) {
        this.id = id;
    }

    public VistaEnvioCorreoId getId() {
        return id;
    }

    public void setId(VistaEnvioCorreoId id) {
        this.id = id;
    }

}
