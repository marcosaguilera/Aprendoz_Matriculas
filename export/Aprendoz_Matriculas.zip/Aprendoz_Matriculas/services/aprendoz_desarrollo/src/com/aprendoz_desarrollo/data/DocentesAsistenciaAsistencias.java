
package com.aprendoz_desarrollo.data;



/**
 *  aprendoz_desarrollo.DocentesAsistenciaAsistencias
 *  05/06/2013 15:48:45
 * 
 */
public class DocentesAsistenciaAsistencias {

    private DocentesAsistenciaAsistenciasId id;

    public DocentesAsistenciaAsistencias() {
    }

    public DocentesAsistenciaAsistencias(DocentesAsistenciaAsistenciasId id) {
        this.id = id;
    }

    public DocentesAsistenciaAsistenciasId getId() {
        return id;
    }

    public void setId(DocentesAsistenciaAsistenciasId id) {
        this.id = id;
    }

}
